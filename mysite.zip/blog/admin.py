from django.contrib import admin
from .models import HomePage, AboutPage, News, ContactPage

admin.site.register(HomePage)
admin.site.register(AboutPage)
admin.site.register(News)
admin.site.register(ContactPage)
